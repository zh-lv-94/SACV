import colorsys
import copy
import time

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torchvision import transforms as T
from PIL import Image
from torch import nn
from utils.utils import cvtColor, preprocess_input, resize_image, show_config

import os
import functools
from utilities.m_net_factory import net_factory
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# -----------------------------------------------------------------------------------#
#   使用自己训练好的模型预测需要修改3个参数
#   model_path、backbone和num_classes都需要修改！
#   如果出现shape不匹配，一定要注意训练时的model_path、backbone和num_classes的修改
# -----------------------------------------------------------------------------------#
class DeeplabV3(object):
    _defaults = {
        # -------------------------------------------------------------------#
        #   model_path指向logs文件夹下的权值文件
        #   训练好后logs文件夹下存在多个权值文件，选择验证集损失较低的即可。
        #   验证集损失较低不代表miou较高，仅代表该权值在验证集上泛化性能较好。
        # -------------------------------------------------------------------#   
        "model_path1":".../Checkpoints/CPS_10p_1.pth",   
        "model_path2":".../Checkpoints/CPS_10p_2.pth",    
        # ----------------------------------------#
        #   所需要区分的类的个数+1
        # ----------------------------------------#
        # "num_classes": 8,
        "num_classes": 4,
        # ----------------------------------------#--------#
        # "backbone": "ghostnet",
        # ----------------------------------------#
        #   输入图片的大小
        # ----------------------------------------#
        "input_shape": [256, 256],
        # ----------------------------------------#
        # -------------------------------------------------#
        #   mix_type参数用于控制检测结果的可视化方式
        #
        #   mix_type = 0的时候代表原图与生成的图进行混合
        #   mix_type = 1的时候代表仅保留生成的图
        #   mix_type = 2的时候代表仅扣去背景，仅保留原图中的目标
        # -------------------------------------------------#
        "mix_type": 1,
        # -------------------------------#
        #   是否使用Cuda
        #   没有GPU可以设置成False
        # -------------------------------#
        "cuda": True,
    }

    # ---------------------------------------------------#
    #   初始化Deeplab
    # ---------------------------------------------------#
    def __init__(self, **kwargs):
        self.__dict__.update(self._defaults)
        for name, value in kwargs.items():
            setattr(self, name, value)
        # ---------------------------------------------------#
        #   画框设置不同的颜色
        # ---------------------------------------------------#
        if self.num_classes <= 21:
            self.colors = [
                (0, 0, 0),
                (128, 0, 0),
                (0, 128, 0),
                (128, 128, 0),
                (0, 0, 128),
                (128, 0, 128),
                (0, 128, 128),
                (128, 128, 128),
                (64, 0, 0),
                (192, 0, 0),
                (64, 128, 0),
                (192, 128, 0),
                (64, 0, 128),
                (192, 0, 128),
                (64, 128, 128),
                (192, 128, 128),
                (0, 64, 0),
                (128, 64, 0),
                (0, 192, 0),
                (128, 192, 0),
                (0, 64, 128),
                (128, 64, 12),
            ]
        else:
            hsv_tuples = [
                (x / self.num_classes, 1.0, 1.0) for x in range(self.num_classes)
            ]
            self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
            self.colors = list(
                map(
                    lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)),
                    self.colors,
                )
            )
        # ---------------------------------------------------#
        #   获得模型
        # ---------------------------------------------------#
        self.generate()

        show_config(**self._defaults)

    # ---------------------------------------------------#
    #   获得所有的分类
    # ---------------------------------------------------#
    def generate(self, onnx=False):
        # -------------------------------#
        #   载入模型与权值
        # -------------------------------#
        model1 = net_factory(net_type='unet_f', in_chns=3, class_num=4)
        model2 = net_factory(net_type='unet_f', in_chns=3, class_num=4)
        
        model1 = nn.DataParallel(model1)  # Training the models on parallel GPU
        model2 = nn.DataParallel(model2)
        self.net1 = model1
        self.net2 = model2

        checkpoint_0 = torch.load(self.model_path1)
        self.net1.load_state_dict(checkpoint_0['state_dict'])
        
        checkpoint_1 = torch.load(self.model_path2)
        self.net2.load_state_dict(checkpoint_1['state_dict'])


        self.net1 = self.net1.eval()
        self.net2 = self.net2.eval()
        print('{} model, and classes loaded.'.format(self.model_path1))
        print('{} model, and classes loaded.'.format(self.model_path2))
        if not onnx:
            if self.cuda:
                self.net1 = nn.DataParallel(self.net1)
                self.net2 = nn.DataParallel(self.net2)
                self.net1 = self.net1.cuda()
                self.net2 = self.net2.cuda()


    def get_miou_png(self, image):
       
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
       
        image = cv2.resize(
                image, (256, 256), interpolation=cv2.INTER_LINEAR
            )
       
        image = Image.fromarray(image)
        
       
        t = T.Compose([T.ToTensor(), T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        image = t(image)
        with torch.no_grad():
            # ---------------------------------------------------#
            #   图片传入网络进行预测
            # ---------------------------------------------------#
                       
            image = image.unsqueeze(0)
            _, _, _, _, _, pr1, _, _, _  = self.net1(image)
            _, _, _, _, _, pr2, _, _, _  = self.net2(image)
            pr = (pr1 + pr2)/2
            pred_mask = F.softmax(pr, dim=1)
            pred_mask = torch.argmax(pred_mask, dim=1).contiguous()
        pr = Image.fromarray(np.uint8(pred_mask[0]))
        return pr
