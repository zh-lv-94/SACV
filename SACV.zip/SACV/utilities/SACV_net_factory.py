from utilities.SACV_unet import UNet, UNet_SACV


def net_factory(net_type="unet_sacv", in_chns=3, class_num=8):
    if net_type == "unet":
        net = UNet(in_chns=in_chns, class_num=class_num).cuda()

    elif net_type == "unet_sacv":
        net = UNet_SACV(in_chns=in_chns, class_num=class_num).cuda()

    else:
        net = None
    return net
