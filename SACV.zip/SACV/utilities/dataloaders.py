# Import the required libraries and modules
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms as T

from PIL import Image
import cv2
import albumentations as A

import os


IMAGE_PATH = ".../train_images/"
MASK_PATH = ".../train_annot/"
IMAGE_PATH_test = ".../val_images/"
MASK_PATH_test = ".../val_annot/"


n_classes = 4


def create_df():
    name = []
    for dirname, _, filenames in os.walk(IMAGE_PATH):
        for filename in filenames:
            name.append(filename.split('.')[0])
    
    return pd.DataFrame({'id': name}, index = np.arange(0, len(name)))

df = create_df()
print('Total Train Images: ', len(df))
XX_train = df['id'].values


def create_df_test():
    name = []
    for dirname, _, filenames in os.walk(IMAGE_PATH_test):
        for filename in filenames:
            name.append(filename.split('.')[0])
    
    return pd.DataFrame({'id': name}, index = np.arange(0, len(name)))

df_test = create_df_test()
print('Total Test Images: ', len(df_test))
X_test = df_test['id'].values

X_train, X_untrain = train_test_split(XX_train, test_size=0.96875, random_state=45) #proportion of training data
# 1/2(0.5), 1/4(0.75), 1/8(0.875), 1/16(0.9375), 1/32(0.96875), 1/64(0.984375)

print('Train Size   : ', len(X_train))
print('Unlabeled_Train Size   : ', len(X_untrain))
print('Test Size    : ', len(X_test))



class NEUDataset(Dataset):
    def __init__(self, img_path, mask_path, X, mean, std, transform=None, patch=False):
        self.img_path = img_path
        self.mask_path = mask_path
        self.X = X
        self.transform = transform
        self.patches = patch
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        img = cv2.imread(self.img_path + self.X[idx] + '.jpg')
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        mask = cv2.imread(self.mask_path + self.X[idx] + '.png', cv2.IMREAD_GRAYSCALE)

        if self.transform is not None:
            aug = self.transform(image=img, mask=mask)
            img = Image.fromarray(aug['image'])
            mask = aug['mask']

        if self.transform is None:
            img = Image.fromarray(img)

        t = T.Compose([T.ToTensor(), T.Normalize(self.mean, self.std)])
        img = t(img)
        mask = torch.from_numpy(mask).long()

        return img, mask

class NEUDataset_SW(Dataset):
    
    def __init__(self, img_path, mask_path, X, mean, std, transform_0, transform_1, transform_2, n_classes=8, patch=False):
        self.img_path = img_path
        self.mask_path = mask_path
        self.X = X
        self.transform_0 = transform_0
        self.transform_1 = transform_1
        self.transform_2 = transform_2
        self.patches = patch
        self.mean = mean
        self.std = std
        self.num = n_classes
        
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        img = cv2.imread(self.img_path + self.X[idx] + '.jpg')
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        mask = cv2.imread(self.mask_path + self.X[idx] + '.png', cv2.IMREAD_GRAYSCALE)
        
        if self.transform_1 is not None:
            aug_0 = self.transform_0(image=img, mask=mask)
            img_0  = Image.fromarray(aug_0['image'])
            mask_0  = aug_0['mask']

            aug_1 = self.transform_1(image=np.asarray(img_0), mask=mask_0)
            img_1 = Image.fromarray(aug_1['image'])
            mask_1 = aug_1['mask']

            aug_2 = self.transform_2(image=np.asarray(img_1), mask=mask_1)  
            img_2 = Image.fromarray(aug_2['image'])
            mask_2 = aug_2['mask']
        
        if self.transform_1 is None:
            img_1 = Image.fromarray(img)
            img_2 = Image.fromarray(img)
        
        t = T.Compose([T.ToTensor(), T.Normalize(self.mean, self.std)])
        img_0 = t(img_0)
        img_1 = t(img_1)
        img_2 = t(img_2)

        
        mask_0 =  torch.from_numpy(mask_0).long()
        mask_1 = torch.from_numpy(mask_1).long()
        mask_2 = torch.from_numpy(mask_2).long()
        
        
        
        return img_0, img_1, img_2, mask_0, mask_1, mask_2

mean = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]


t_train = A.Compose(
    [
        A.Resize(256, 256, interpolation=cv2.INTER_NEAREST)       
    ]
)

t_untrain_weak = A.Compose([A.Resize(256, 256, interpolation=cv2.INTER_NEAREST),
                    A.HorizontalFlip(p=0.3),
                    A.VerticalFlip(p=0.3),
                    A.ShiftScaleRotate(p=0.3),
                    A.RandomCrop(128,128,p=0.3),
                    A.Resize(256, 256, interpolation=cv2.INTER_NEAREST),
                    A.RandomRotate90(p=0.3)       
                    ]) 
t_untrain_medium = A.Compose([A.Resize(256, 256, interpolation=cv2.INTER_NEAREST), 
                    A.CLAHE(clip_limit=4.0,tile_grid_size=(8,8),always_apply=False, p=0.3),
                    A.ColorJitter (brightness=0.5, contrast=0.5, saturation=0.5, hue=0.5, always_apply=False, p=0.3),
                    A.RGBShift(r_shift_limit=30, g_shift_limit=30, b_shift_limit=30, p = 0.2),
                    A.ChannelShuffle(always_apply=False,p=0.2),
                    ]) 
  
t_untrain_strong = A.Compose([A.Resize(256, 256, interpolation=cv2.INTER_NEAREST), 
                    A.OneOf([A.AdvancedBlur(blur_limit=15, p = 1), A.MotionBlur(p = 1), A.MedianBlur(blur_limit=15, p = 1)], p=0.4),
                    A.OneOf([A.RandomFog(p = 1), A.RandomGamma(p = 1), A.RandomShadow(p = 1), A.RandomSnow(p = 1)], p=0.1),
                    A.CoarseDropout(max_holes=12, max_height=6, max_width=6, fill_value=0, p=0.1),
                    A.OneOf([A.GaussNoise(var_limit=50, p = 1), A.ISONoise(p = 1), A.MultiplicativeNoise(multiplier=[0.5, 1.5], elementwise=True, per_channel=True, p=1)], p=0.4),
                    ])     

t_val = A.Compose([A.Resize(256, 256, interpolation=cv2.INTER_NEAREST)])
t_test = A.Compose([A.Resize(256, 256, interpolation=cv2.INTER_NEAREST)])


train_set = NEUDataset_SW(IMAGE_PATH, MASK_PATH, X_train, mean, std, t_untrain_weak, t_untrain_medium, t_untrain_strong, patch=False)
unlabeled_train_set = NEUDataset_SW(IMAGE_PATH, MASK_PATH, X_untrain, mean, std, t_untrain_weak, t_untrain_medium, t_untrain_strong, patch=False)
test_set = NEUDataset_SW(
    IMAGE_PATH_test, MASK_PATH_test, X_test, mean, std, t_val, t_untrain_weak, t_untrain_strong, patch=False)

# dataloader
batch_size = 8

train_loader = DataLoader(
    train_set, batch_size=batch_size, num_workers=4, pin_memory=True, shuffle=True
)
unlabeled_loader = DataLoader(
    unlabeled_train_set,
    batch_size=batch_size,
    num_workers=4,
    pin_memory=True,
    shuffle=True
)

val_loader = DataLoader(test_set, batch_size=batch_size, num_workers = 4, pin_memory = True,  shuffle=False) 
